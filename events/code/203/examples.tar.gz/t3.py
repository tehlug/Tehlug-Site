#!/usr/bin/python3
import os
import sys
def application(environ, start_response):
    status = '200 OK' 
    output = str(sys.path).encode('utf-8')
    response_headers = [('Content-type', 'text/plain'),
                        ('Content-Length', str(len(output)))]
    start_response(status, response_headers)

    return [output]
