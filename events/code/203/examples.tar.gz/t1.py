try:
    main_run += 1
except: 
    main_run = 1
def application(environ, start_response):
    try:
        application.main_run += 1
    except: 
        application.main_run = 1
    status = '200 OK' 
    output = 'main_run = {0} and application run = {1}'.format(main_run, application.main_run).encode('utf-8')
    response_headers = [('Content-type', 'text/plain'),
                        ('Content-Length', str(len(output)))]
    start_response(status, response_headers)
    return [output] 
