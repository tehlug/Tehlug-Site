def application(environ, start_response):
    status = '200 OK'
    if not environ['mod_wsgi.process_group']:
      output = 'EMBEDDED MODE'.encode('utf-8')
    else:
      output = 'DAEMON MODE'.encode('utf-8')
    response_headers = [('Content-Type', 'text/plain'),
                        ('Content-Length', str(len(output)))]
    start_response(status, response_headers)
    return [output] 
