<?php

if( curl_getinfo($ch)['http_code'] == 200 )
	echo 'Target Website is Up....';

	
/*
curl_getinfo($ch):
	Array
	(
		[url] 						=> http://192.168.1.20:7001/mf/
		[content_type] 				=> text/html;charset=windows-1256
		[http_code] 				=> 200
		[header_size] 				=> 293
		[request_size] 				=> 232
		[filetime] 					=> -1
		[ssl_verify_result] 		=> 0
		[redirect_count] 			=> 0
		[total_time] 				=> 0.093
		[namelookup_time] 			=> 0
		[connect_time] 				=> 0.015
		[pretransfer_time] 			=> 0.015
		[size_upload] 				=> 0
		[size_download] 			=> 9200
		[speed_download] 			=> 98924
		[speed_upload] 				=> 0
		[download_content_length] 	=> -1
		[upload_content_length]   	=> 0
		[starttransfer_time] 	  	=> 0.031
		[redirect_time] 			=> 0
		[certinfo] 					=> Array()
		[primary_ip] 				=> 192.168.1.20
		[primary_port] 				=> 7001
		[local_ip] 					=> 10.1.106.66
		[local_port] 				=> 49623
		[redirect_url] 				=> 
	)
*/