<?php
// ~200 Predefined Constants

curl_setopt($ch, CURLOPT_URL, 			$url);
curl_setopt($ch, CURLOPT_REFERER, 		$url);
curl_setopt($ch, CURLOPT_AUTOREFERER, 	true);  // TRUE to automatically set the Referer
curl_setopt($ch, CURLOPT_HEADER, 		false); // TRUE to include the header in the output. 
curl_setopt($ch, CURLOPT_ENCODING, 		'gzip, deflate');
curl_setopt($ch, CURLOPT_USERAGENT, 	$agent);

curl_setopt($ch, CURLOPT_COOKIEFILE, 	$cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, 	$cookie);

// It will force libcurl to ignore all cookies it is about to load that are "session cookies" from the previous session.
curl_setopt($ch, CURLOPT_COOKIESESSION, true);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION,true); // follow any "Location: " header that the server sends as part of the HTTP header 
curl_setopt($ch, CURLOPT_MAXREDIRS, 	2);    // Limit redirections to 2
curl_setopt($ch, CURLOPT_RETURNTRANSFER,false);
curl_setopt($ch, CURLOPT_TIMEOUT, 		$timeout);

curl_setopt($ch, CURLOPT_POST, 			true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 	$POST_Array);

// Telling PHP/CURL not to perform server authentication
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // No certificate

// Using a Proxy with PHP/CURL // Anonymity Is a Process, Not a Feature
// Anonymity Is a Process, Not a Feature
curl_setopt($session_id, CURLOPT_PROXY, $proxy_ip.":".$proxy_port);
curl_setopt($session_id, CURLOPT_PROXY_TYPE, CURLPROXY_SOCKS5); // defaults to CURLPROXY_HTTP

curl_setopt($ch, CURLOPT_USERPWD, "webbot:sp1der"); // Send credentials
curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);         // // Binary Transfer



// CURLOPT_NOBODY :: TRUE to exclude the body from the output



// Download File
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'http://youhack.me/demo/download.zip.zip');
$fp = fopen('/path/to/download.zip', 'w');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_exec ($ch);//Execute Transaction
