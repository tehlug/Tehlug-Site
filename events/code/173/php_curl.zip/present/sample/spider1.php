<?php
# Initialization
include("lib/LIB_http.php"); 				// http library
include("lib/LIB_parse.php"); 				// parse library
include("lib/LIB_resolve_addresses.php"); 	// Address resolution library
include("lib/LIB_exclusion_list.php"); 		// List of excluded keywords
include("lib/LIB_simple_spider.php"); 		// Spider routines used by this app

$SEED_URL 		 = "10.1.106.69/estelam_sarbaz/users/login";
set_time_limit(3600); 		// Don't let PHP time out
$MAX_PENETRATION = 1; 		// Set spider penetration depth
$FETCH_DELAY     = 1; 		// Wait 1 second between page fetches
$ALLOW_OFFISTE   = false; 	// Don't let spider roam from seed domain
$spider_array    = array(); // Initialize the array that holds links


# Get links from $SEED_URL
echo "Harvesting Seed URL  <br><br>";

$temp_link_array = harvest_links($SEED_URL);
$spider_array    = archive_links($spider_array, 0, $temp_link_array);

# Spider links from remaining penetration levels
for($penetration_level=1; $penetration_level<=$MAX_PENETRATION; $penetration_level++) {

	$previous_level = $penetration_level - 1;
	for($xx=0; $xx<count($spider_array[$previous_level]); $xx++) {
	
		unset($temp_link_array);
		$temp_link_array = harvest_links($spider_array[$previous_level][$xx]);
		echo "Level=$penetration_level, xx=$xx of ".count($spider_array[$previous_level])."  <br><br>";
		$spider_array = archive_links($spider_array, $penetration_level, $temp_link_array);
	}
}


include("LIB/LIB_download_images.php");
// Adding the Payload
// Download images from pages referenced in $spider_array
for($penetration_level=1; $penetration_level<=$MAX_PENETRATION; $penetration_level++)
	for($xx=0; $xx<count($spider_array[$previous_level]); $xx++)
		download_images_for_page($spider_array[$previous_level][$xx]);