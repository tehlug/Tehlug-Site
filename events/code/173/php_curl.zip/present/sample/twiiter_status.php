<?php
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "http://twitter.com/statuses/user_timeline/$twitter_id.xml?count=1");
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
$src = curl_exec($c);
curl_close($c);

// OR test friendship between two users