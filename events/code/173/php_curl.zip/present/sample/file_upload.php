<?php
// 
// This sample shows how to fill in and submit data to a form that looks like:
//
//   <form enctype="multipart/form-data" action="uploader.php" method="post">
//   	<input type="file" name="sampfile">
//   	<input type="text" name="filename">
//   	<input type="text" name="shoesize">
//  	<input type="submit" value="upload">
//   </form>

   $uploadfile = "/tmp/upload.jpg"; 
   $ch = curl_init("http://sample.com/uploader.php");  
   curl_setopt($ch, CURLOPT_POSTFIELDS,
               array('sampfile' => "@$uploadfile",
                     'shoesize' => '9',
                     'filename' => "fake name for file"));
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   $postResult = curl_exec($ch);
   curl_close($ch);