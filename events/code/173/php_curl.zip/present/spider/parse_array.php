<?php

include("lib/LIB_parse.php"); # Include parse library
include("lib/LIB_http.php"); # Include PHP/CURL library

$web_page = http_get($target="http://192.168.1.20:7001/mf", $referer="");
$meta_tag_array = parse_array($web_page['FILE'], "<meta", ">");

for($xx=0; $xx<count($meta_tag_array); $xx++)
	echo $meta_tag_array[$xx]."\n";

