<?php
# Include libraries
include("lib/LIB_parse.php");
include("lib/LIB_http.php");

// Download the web page
$web_page = http_get($target="http://192.168.1.20:7001/mf", $referer="");
	
// Remove all JavaScript
$noformat = remove($web_page['FILE'], "<script", "</script>");
// Strip out all HTML formatting
$unformatted = strip_tags($noformat);
// Remove unwanted white space
$noformat = str_replace("\t", "", $noformat); // Remove tabs
$noformat = str_replace("&nbsp;", "", $noformat); // Remove non-breaking spaces
$noformat = str_replace("\n", "", $noformat); // Remove line feeds
echo $noformat;