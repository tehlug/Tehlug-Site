<?php
// Include libraries
include("lib/LIB_http.php");
include("lib/LIB_parse.php");

// Identify the server you want to get local time from
$target = "10.1.106.69";

// Request the httpd head
$header_array = http_header($target, $ref="");

// Parse the local server time from the header
$local_server_time = return_between($header_array['FILE'], $start="Date:", $stop="<br>", EXCL);
// Convert the local server time to a timestamp

$local_server_time_ts = strtotime($local_server_time);
// Display results
echo "<br>Returned header:<br>";
echo $header_array['FILE']."<br>";
echo "Parsed server timestamp = ".$local_server_time_ts ."<br>";
echo "Formatted server time = ".date("r", $local_server_time_ts)."<br>";
