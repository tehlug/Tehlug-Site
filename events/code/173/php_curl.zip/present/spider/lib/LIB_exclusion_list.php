<?php
# The spider will exclude any links containing any of the following substrings
$exclusion_array[] = "googlesyndication";         // Exclude Google AdWords links.
$exclusion_array[] = "doubleclick.net";           // Exclude doubleclick banner ads
?>