<?php
# Include libraries
include("lib/LIB_http.php");
include("lib/LIB_parse.php");
include("lib/LIB_resolve_addresses.php");
include("lib/LIB_http_codes.php");

# Identify the target web page and the page base
$target    = "http://10.1.106.69/estelam_sarbaz/";
$page_base = "http://10.1.106.69/";

# Download the web page
$downloaded_page = http_get($target, $ref="");

# Parse the links
$link_array = parse_array($downloaded_page['FILE'], $beg_tag="<a", $close_tag=">");

?>
<b>Status of links on <?php echo $target?></b><br>
<table border="1" cellpadding="1" cellspacing="0">
<tr bgcolor="#e0e0e0">
<th>URL</th>
<th>HTTP CODE</th>
<th>MESSAGE</th>
<th>DOWNLOAD TIME (seconds)</th>
</tr>
<?php
for($xx=0; $xx<count($link_array); $xx++) {
	// Verification and display go here
	
	// Parse the HTTP attribute from link
	$link = get_attribute($tag=$link_array[$xx], $attribute="href");

	// Create a fully resolved URL
	$fully_resolved_link_address = resolve_address($link, $page_base);

	// Download the page referenced by the link and evaluate
	$downloaded_link = http_get($fully_resolved_link_address, $target);

	?>
	<tr>
		<td align="left"><?php echo $downloaded_link['STATUS']['url'] ?></td>
		<td align="right"><?php echo $downloaded_link['STATUS']['http_code'] ?></td>
		<td align="left"><?php echo $status_code_array[$downloaded_link['STATUS']['http_code']] ?></td>
		<td align="right"><?php echo $downloaded_link['STATUS']['total_time'] ?></td>
	</tr>
	<?php
}


$YOUR_HTTP_CODE = 404;
echo $status_code_array[$YOUR_HTTP_CODE]['MSG'];