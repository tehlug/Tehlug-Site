<?php
# Include http, parse, and address resolution libraries
include("LIB_http.php");
include("LIB_parse.php");
include("LIB_resolve_addresses.php");

# Identify the target web page and the page base
$target = "http://www.WebbotsSpidersScreenScrapers.com/head_redirection_test.php";
$page_base = "http://www.WebbotsSpidersScreenScrapers.com";

# Download the web page
$page = http_get($target, $ref="");

# Parse the <head></head>
$head_section = return_between($string=$page['FILE'], $start="<head>", $end="</head>", $type=EXCL);

# Create an array of all the meta tags
$meta_tag_array = parse_array($head_section, $beg_tag="<meta", $close_tag=">");

# Examine each meta tag for a redirection command
for($xx=0; $xx<count($meta_tag_array); $xx++) {
	# Look for http-equiv attribute
	$meta_attribute = get_attribute($meta_tag_array[$xx], $attribute="http-equiv");
	
	if(strtolower($meta_attribute)=="refresh") {
		$new_page = return_between($meta_tag_array[$xx], $start="URL", $end=">", $type=EXCL);
		
		# Clean up URL
		$new_page = trim(str_replace("", "", $new_page));
		$new_page = str_replace("=", "", $new_page);
		$new_page = str_replace("\"", "", $new_page);
		$new_page = str_replace("'", "", $new_page);
		
		# Create fully resolved URL
		$new_page = resolve_address($new_page, $page_base);
	}
	break;
}

# Echo results of script
echo "HTML Head redirection detected<br>";
echo "Redirect page = ".$new_page;