<?php
include("lib/LIB_http.php");
# Get the web page
$page = http_get($target="www.schrenk.com", $ref="");
# Vector to error handler if error code detected
if($page['STATUS']['http_code']!="200")
error_handler("BAD RESULT", $page['STATUS']['http_code']); 