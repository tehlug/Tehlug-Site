<?php
# Include libraries
include("lib/LIB_http.php");

// Download the web page
$web_page = http_get($target="http://192.168.1.20:7001/mf", $referer="");

$uncompressed_size = strlen($web_page['FILE']);
$compressed_size = strlen(gzcompress($web_page['FILE'], $compression_value =9));
$noformat_size = strlen(strip_tags($web_page['FILE']));

echo 'Uncompressed: ' . $uncompressed_size . '<br>';
echo 'compressed_size: ' . $compressed_size . '<br>';
echo 'noformat_size: ' . $noformat_size . '<br>';