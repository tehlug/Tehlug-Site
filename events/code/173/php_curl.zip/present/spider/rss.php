<?php
# Include libraries
include("LIB_http.php");
include("LIB_parse.php");
include("LIB_rss.php");


$target = "http://www.ft.com/rss/home/uk";
$rss_array = download_parse_rss($target);
display_rss_array($rss_array);



$filter_array[]="webbots";
$filter_array[]="web spiders";
$filter_array[]="spiders";

function download_parse_rss($target, $filter_array) {

	# Download the RSS page
	$news = http_get($target, "");
	
	# Parse title and copyright notice
	$rss_array['TITLE'] = return_between($news['FILE'], "<title>", "</title>", EXCL);
	$rss_array['COPYRIGHT'] = return_between($news['FILE'], "<copyright>", "</copyright>", EXCL);
	
	# Parse the items
	$item_array = parse_array($news['FILE'], "<item>", "</item>");
	
	for($xx=0; $xx<count($item_array); $xx++) {
	
		# Filter stories for relevance
		for($keyword=0; $keyword<count($filter_array); $keyword ++) {
		
			if(stristr($item_array[$xx], $filter_array[$keyword])) {
			
				$rss_array['ITITLE'][$xx] = return_between($item_array[$xx], "<title>", "</title>", EXCL);
				$rss_array['ILINK'][$xx] = return_between($item_array[$xx], "<link>", "</link>", EXCL);
				$rss_array['IDESCRIPTION'][$xx] = return_between($item_array[$xx], "<description>", "</description>", EXCL);
				$rss_array['IPUBDATE'][$xx] = return_between($item_array[$xx], "<pubDate>", "</pubDate>", EXCL);
			}
		}
	}
	return $rss_array;
}