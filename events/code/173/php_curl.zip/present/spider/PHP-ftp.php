<?php
//PHP provides built-in functions that closely resemble standard FTP commands.

ftp_cdup($ftp); 									//Makes the parent directory the current directory
ftp_chdir($ftp, "directory/path") 					//Changes the current directory
ftp_delete($ftp, "file_name") 						//Deletes a file
ftp_get($ftp, "local file", "remote file", MODE) 	//Copies the remote file to the local file where MODE indicates if the remote file is FTP_ASCII or FTP_BINARY
ftp_mkdir($ftp, "directory name") 					//Creates a new directory
ftp_rename($ftp, "file name") 						//Renames a file or a directory on the FTP server
ftp_put($ftp, "remote file", "local file", MODE)	//Copies the local file to the remote file where MODE indicates if the local file is FTP_ASCII or FTP_BINARY
ftp_rmdir($ftp, "directory/path") 					//Removes a directory
ftp_rawlist($ftp, "directory/path") 				//Returns an array with each array element containing directory information about a file