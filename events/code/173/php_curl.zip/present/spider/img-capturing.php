<?php
include("lib/LIB_download_images.php");
$target="http://192.168.1.20:7001/mf";
download_images_for_page($target);

