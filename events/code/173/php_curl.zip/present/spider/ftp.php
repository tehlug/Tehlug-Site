<?php
include("LIB_MAIL.php");
$mail_addr['to']   = "admin@somedomain.com";
$mail_addr['from'] = "admin@somedomain.com";

// Define the source FTP server, file location, and authentication values
define("REMOTE_FTP_SERVER", "remote_FTP_address"); // Domain name or IP address
define("REMOTE_USERNAME", "yourUserName");
define("REMOTE_PASSWORD", "yourPassword");
define("REMOTE_DIRCTORY", "daily_sales");
define("REMOTE_FILE", "sales.txt");

// Define the corporate FTP server, file location, and authentication values
define("CORP_FTP_SERVER", "corp_FTP_address");
define("CORP_USERNAME", "yourUserName");
define("CORP_PASSWORD", "yourPassword");
define("CORP_DIRCTORY", "sales_reports");
define("CORP_FILE", "store_03_".date("Y-M-d"));

function report_error_and_quit($error_message, $server_connection) {
	global $mail_addr;
	
	// Send error message
	echo "$error_message, $server_connection";
	formatted_mail($error_message, $error_message, $mail_addr, "text/plain");

	// Attempt to log off the server gracefully if possible
	ftp_close($server_connection);
	
	// It is not traditional to end a function this way, but since there is
	// nothing to return or do, it is best to exit
	exit();
}	


// Negotiate a socket connection to the remote FTP server
$remote_connection_id = ftp_connect(REMOTE_FTP_SERVER);

// Log in (authenticate) the source server
if(!ftp_login($remote_connection_id, REMOTE_USERNAME, REMOTE_PASSWORD))
	report_error_and_quit("Remote ftp_login failed", $remote_connection_id);



// Move the directory of the source file
if(!ftp_chdir($remote_connection_id, REMOTE_DIRCTORY))
	report_error_and_quit("Remote ftp_chdir failed", $remote_connection_id);
	
// Download the file
if(!ftp_get($remote_connection_id, "temp_file", REMOTE_FILE, FTP_ASCII))
	report_error_and_quit("Remote ftp_get failed", $remote_connection_id);
	
// Close connections to the remote FTP server
ftp_close($remote_connection_id);


// Negotiate a socket connection to the corporate FTP server
$corp_connection_id = ftp_connect(CORP_FTP_SERVER);

// Log in to the corporate server
if(!ftp_login($corp_connection_id, CORP_USERNAME, CORP_PASSWORD))
	report_error_and_quit("Corporate ftp_login failed", $corp_connection_id);

// Move the destination directory
if(!ftp_chdir($corp_connection_id, CORP_DIRECTORY))
	report_error_and_quit("Corporate ftp_chdir failed", $corp_connection_id);
	
// Upload the file
if(!ftp_put($corp_connection_id, CORP_FILE, "temp_file", FTP_ASCII))
	report_error_and_quit("Corporate ftp_put failed", $corp_connection_id);
	
// Close connections to the corporate FTP server
ftp_close($corp_connection_id);



// Send notification that the webbot ran successfully
formatted_mail("ftpbot ran successfully at ".time("M d,Y h:s"), "",
$mail_addr, $content_type);






