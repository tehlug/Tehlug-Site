<?php
include("lib/LIB_pop3.php"); // Include POP3 command libray

define("SERVER", "your.mailserver.net"); // Your POP3 mailserver
define("USER", "your@emailsccount.com "); // Your POP3 email address
define("PASS", "your_password"); // Your POP3 password


# Connect to POP3 server
$connection_array = POP3_connect(SERVER, USER, PASS);
$POP3_connection  = $connection_array['handle'];

if($POP3_connection) {
	// Create an array, which is the result of a POP3 LIST command
	$list_array = POP3_list($POP3_connection);
	
	# Request and display all messages in $list_array
	for($xx=0; $xx<count($list_array); $xx++) {
	
		// Parse the mail ID from the message size
		list($mail_id, $size) = explode(" ", $list_array[$xx]);
		
		// Request the message for the specific mail ID
		$message = POP3_retr($POP3_connection, $mail_id);
		
		// Display message and place mail ID, size, and message in an array
		echo "$mail_id, $size\n";
		$mail_array[$xx]['ID']      = $mail_id;
		$mail_array[$xx]['SIZE']    = $size;
		$mail_array[$xx]['MESSAGE'] = $message;
		
		// Display message in <xmp></xmp> tags to disable HTML
		// (in case script is run in a browser)
		echo "<xmp>$message</xmp>";
		
			// Delete the message from the server
		POP3_delete($POP3_connection, $mail_id);
	}
	
	// End the server session
	echo POP3_quit($POP3_connection);
	
} else {
	echo "Login error";
}









