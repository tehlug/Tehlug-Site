jsfpress
========

a presentation about javascript frameworks, backbone, ember and angular.
visit [presentation](http://jajool.github.io/jsfpress)